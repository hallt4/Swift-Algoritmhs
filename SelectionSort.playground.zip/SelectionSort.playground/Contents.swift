//: Playground - noun: a place where people can play

let numberList: Array<Int> = [8, 2, 10, 9, 11, 1, 7, 3, 4]


func selectionSort(numberList: Array<Int>) -> Array<Int> {
    //mutated copy
    var output = numberList
    
    for primaryIndex in 0 ..< output.count {
        var minimum = primaryIndex
        
        
        //iterate the unsorted half
        for secondaryIndex in primaryIndex + 1 ..< output.count {
            if output[secondaryIndex] < output[minimum] {
                minimum = secondaryIndex
            }
        }
        
        //swap minimum
        if primaryIndex != minimum {
            swap(&output[primaryIndex], &output[minimum])
        }
        
        print(output)
        
    }
    
    return output
}

selectionSort(numberList)